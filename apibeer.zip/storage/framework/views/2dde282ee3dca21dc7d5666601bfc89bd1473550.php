# Introduction

The body of your message.


Thanks
<?php /**PATH C:\dev\api\resources\views/mail/newelcome.blade.php ENDPATH**/ ?>