<?php


namespace App\Repositories\Interfaces;


interface StoreCountryRepositoryInterface
{
    public function addCountry($data);
}
