<?php


namespace App\Services\Interfaces;


interface TasteAttributesOfBeerServiceInterface
{
    public function addToBeer();

    public function removeFromBeer();
}
