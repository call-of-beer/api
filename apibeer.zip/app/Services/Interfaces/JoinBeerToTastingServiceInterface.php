<?php


namespace App\Services\Interfaces;


interface JoinBeerToTastingServiceInterface
{
    public function joinBeerToTasting($beer, $tasting);
}
