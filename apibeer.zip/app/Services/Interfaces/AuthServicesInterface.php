<?php


namespace App\Services\Interfaces;


interface AuthServicesInterface
{
//    public function Login();

    public function Register($data);
}
