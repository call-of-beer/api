<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    use HasFactory;

    /**
     * @var string
     */
    protected $table = 'ratings';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'aroma', 'color', 'taste', 'bitterness', 'texture'
    ];

    public function beer()
    {
        return $this->belongsTo(Beer::class, 'beer_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function comment()
    {
        return $this->hasOne(Comment::class);
    }

    public function tasting()
    {
        return $this->belongsTo(Tasting::class, 'tasting_id', 'id');
    }
}
